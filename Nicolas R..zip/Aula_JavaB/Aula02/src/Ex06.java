public class Ex06 {
    static void main() {
        System.out.println("          *");
        System.out.println("         XXX");
        System.out.println("        XXXXX");
        System.out.println("       XXXXXXX");
        System.out.println("      XXXXXXXXX");
        System.out.println("     XXXXXXXXXXX");
        System.out.println("    XXXXXXXXXXXXX");
        System.out.println("   XXXXXXXXXXXXXXX");
        System.out.println("        XXXXX");
        System.out.println("        XXXXX");
    }
}
