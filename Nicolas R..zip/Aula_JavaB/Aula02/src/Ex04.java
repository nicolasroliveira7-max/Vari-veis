public class Ex04 {
    static void main() {
        System.out.println("ALUNO\t\t     NOTA");
        System.out.println("========\t\t======");
        System.out.println("Dilma Rouseff\t 5,0");
        System.out.println("Wanessa Wolf \t 9,0");
        System.out.println("Bolsonaro    \t 10,0");
        System.out.println("Lula         \t 9,0");
        System.out.println("Temer        \t 7,0");
        System.out.println("Carminha     \t 10,0");
    }
}
