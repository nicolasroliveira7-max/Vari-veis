public class Ex03 {
    static void main() {
        String nome = "Wanessa Wolf";
        int CEP= 40028922;
        String Endereço= "Rua dos Grilos, número 69, bairro dos Rouseff";
        System.out.print("Nome: ");
        System.out.println(nome);
        System.out.print("CEP: ");
        System.out.println(CEP);
        System.out.print("Endereço: ");
        System.out.println(Endereço);
    }
}
