public class Ex1b {
    static void main() {
        System.out.println("Hoje o dia está nublado!");
        int idade = 16;
        String nome = "Nicolas";
        System.out.print("Nome: ");
        System.out.print(nome);
        System.out.print(" Idade: ");
        System.out.print(idade);

    }
}
