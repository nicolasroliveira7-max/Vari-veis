public class Ex02 {
    static void main() {
        String nome ="Dilma Rouseff";
        int idade= 78;
        String curso="Ex-presidenta";
        String escola= "Planalto";
        String Recado = "Olá, presidenta Dilma!";
        System.out.print("Nome: ");
        System.out.println(nome);
        System.out.print("Idade: ");
        System.out.println(idade);
        System.out.print("Escola: ");
        System.out.println(escola);
        System.out.print("Recado:");
        System.out.println(Recado);

    }
}
