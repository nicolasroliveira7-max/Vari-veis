public class Ex05 {
    static void main() {
        System.out.println("XXXXXXXXX        XXXXXXXXX");
        System.out.println("X       X        X       X");
        System.out.println("X       X        X       X");
        System.out.println("XXXXXXXXX        XXXXXXXXX");
        System.out.println("  ");
        System.out.println("            X");
        System.out.println("X                        X");
        System.out.println(" X                      X");
        System.out.println("   XXXXXXXXXXXXXXXXXXXX");
    }
}
